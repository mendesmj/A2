// importação dos modulos
const express = require("express");
var fs = require('fs');

// Cria as rotas do meu webService:
const router = express.Router();



//Rotas

router.get("/", (req , res) => {
    res.sendFile(__dirname + "/views/index.html");
});

router.get('/produtos',(req , res) => {
    res.sendFile(__dirname + "/views/produtos.html");
});

router.get('/catalogos',(req , res) => {
    res.sendFile(__dirname + "/views/catalogo.html");
});

router.get('/contatos',(req , res) => {
    res.sendFile(__dirname + "/views/contato.html");
});


//Olha o tipo de arquivo e coloca na rota certa, coloca caminha exato do diretorio EX: C:/recursos/arquivo.md


router.get('/tipoDocx',(req , res) => {
    res.sendFile("Coloca aqui o diretório certo /recursos/arquivo.docx");
});

router.get('/tipoJpeg',(req , res) => {
    res.sendFile("Coloca aqui o diretório certo /recursos/arquivo.jpeg");
});

router.get('/tipoMp3',(req , res) => {
    res.sendFile("Coloca aqui o diretório certo /recursos/arquivo.jpeg");
});

router.get('/tipoMp4',(req , res) => {
    res.sendFile("Coloca aqui o diretório certo /recursos/arquivo.jpeg");
});

router.get('/tipoJson',(req , res) => {
    res.sendFile("Coloca aqui o diretório certo /recursos/arquivo.jpeg");
});

router.get('/tipoMd',(req , res) => {
    res.sendFile("Coloca aqui o diretório certo /recursos/arquivo.jpeg");
});






// Configuração para exportação
const index = express();
index.use('/', router);

module.exports = index;